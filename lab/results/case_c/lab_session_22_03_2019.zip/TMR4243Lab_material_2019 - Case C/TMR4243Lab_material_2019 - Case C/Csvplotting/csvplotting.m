% simple = importdata('Simple_allocation_13_08_24.csv');

error_dyn = importdata('position_dead_est_17_33_49.csv');

% heading_step = 150;

% xpos_simple = simple.data(:,1);
% 
% ypos_simple = simple.data(:,2);
% 
% heading_simple = simple.data(:,3);
% 
% tau_surge_simple = simple.data(:,4);
% 
% tau_sway_simple = simple.data(:,5);
% 
% tau_yaw_simple = simple.data(:,6);


% figure;
% plot(ypos_simple, xpos_simple);
% hold on;
% quiver(ypos_simple(1:heading_step:end), xpos_simple(1:heading_step:end), ... 
%     sin(heading_simple(1:heading_step:end)), cos(heading_simple(1:heading_step:end)));
% title('Ship position');
% xlabel('E-position');
% ylabel('N-position');

xpos = error_dyn.data(:,1);

ypos = error_dyn.data(:,2);

heading = error_dyn.data(:,3);

xpos_est = error_dyn.data(:,4);

ypos_est = error_dyn.data(:,5);

heading_est = error_dyn.data(:,6);

figure;
subplot(3,1,1);
hold on
mtit('Error dynamics observer')
plot(xpos); 
plot(xpos_est);
legend('xpos','xpos_{est}');
ylabel('x-position')
subplot(3,1,2)
hold on
plot(ypos);
plot(ypos_est);
legend('ypos','ypos_{est}');
ylabel('y-position')
subplot(3,1,3)
hold on
plot(heading);
plot(heading_est);
legend('heading','heading_{est}');
ylabel('heading')
xlabel('*10^-^2 [s]')



%corresponding movements
% figure;
% plot(ypos_full, xpos_full);
% hold on;
% quiver(ypos_full(1:heading_step:end), xpos_full(1:heading_step:end), ... 
%     sin(heading_full(1:heading_step:end)), cos(heading_full(1:heading_step:end)));
% title('Ship position');
% xlabel('E-position');
% ylabel('N-position');
% 
% %Plotting commanded thrusts
% figure;
% subplot(311)
% mtit('Commanded thrust')
% plot(tau_surge_full)
% ylabel('surge[N]')
% subplot(312)
% plot(tau_sway_full)
% ylabel('sway[N]')
% subplot(313)
% plot(tau_yaw_full)
% ylabel('yaw[N]')


