<portlist>
<inport> Id = "1"  Name = "posYLeft" Width = "1" DataType = "real_T" </inport>
<inport> Id = "2"  Name = "posXLeft" Width = "1" DataType = "real_T" </inport>
<inport> Id = "3"  Name = "Selector" Width = "1" DataType = "real_T" </inport>
<inport> Id = "4"  Name = "posXRight" Width = "1" DataType = "real_T" </inport>
<inport> Id = "5"  Name = "R2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "6"  Name = "L2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "7"  Name = "NIVeriStand In2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "8"  Name = "Pose/x_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "9"  Name = "Pose/y_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "10"  Name = "Pose/psi_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "11"  Name = "Observer2/Noise gain" Width = "1" DataType = "real_T" </inport>
<inport> Id = "12"  Name = "Observer2/Observer gain L1//L2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "13"  Name = "Observer2/Observer gain L3" Width = "1" DataType = "real_T" </inport>
<inport> Id = "14"  Name = "IMU/Acc_z" Width = "1" DataType = "real_T" </inport>
<inport> Id = "15"  Name = "IMU/Acc_x" Width = "1" DataType = "real_T" </inport>
<inport> Id = "16"  Name = "IMU/Acc_y" Width = "1" DataType = "real_T" </inport>
<inport> Id = "17"  Name = "IMU/Gyro_x" Width = "1" DataType = "real_T" </inport>
<inport> Id = "18"  Name = "IMU/Gyro_y" Width = "1" DataType = "real_T" </inport>
<inport> Id = "19"  Name = "IMU/Gyro_z" Width = "1" DataType = "real_T" </inport>
<outport> Id = "1"  Name = "eta_hat" Width = "3" DataType = "real_T" </outport>
<outport> Id = "2"  Name = "nu_hat" Width = "3" DataType = "real_T" </outport>
<outport> Id = "3"  Name = "b_hat" Width = "3" DataType = "real_T" </outport>
<outport> Id = "4"  Name = "tau simple1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "5"  Name = "tau simple2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "6"  Name = "tau simple3" Width = "1" DataType = "real_T" </outport>
<outport> Id = "7"  Name = "tau full1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "8"  Name = "tau full2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "9"  Name = "tau full3" Width = "1" DataType = "real_T" </outport>
<outport> Id = "10"  Name = "tau simple" Width = "3" DataType = "real_T" </outport>
<outport> Id = "11"  Name = "tau full" Width = "3" DataType = "real_T" </outport>
<outport> Id = "12"  Name = "eta_testing" Width = "3" DataType = "real_T" </outport>
<outport> Id = "13"  Name = "QTM_SCOPEPSI" Width = "1" DataType = "real_T" </outport>
<outport> Id = "14"  Name = "QTM_SCOPEX" Width = "1" DataType = "real_T" </outport>
<outport> Id = "15"  Name = "QTM_SCOPEY" Width = "1" DataType = "real_T" </outport>
<outport> Id = "16"  Name = "selector full" Width = "1" DataType = "real_T" </outport>
<outport> Id = "17"  Name = "selector simple" Width = "1" DataType = "real_T" </outport>
<outport> Id = "18"  Name = "u/alpha_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "19"  Name = "u/omega_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "20"  Name = "u/omega_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "21"  Name = "u/alpha_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "22"  Name = "u/u_BT" Width = "1" DataType = "real_T" </outport>
<outport> Id = "23"  Name = "u/u_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "24"  Name = "u/u_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "25"  Name = "Observer2/Eta_bar" Width = "3" DataType = "real_T" </outport>
<outport> Id = "26"  Name = "IMU/IMU_SCOPEZ" Width = "1" DataType = "real_T" </outport>
</portlist>
