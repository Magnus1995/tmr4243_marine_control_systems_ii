<parameterlist>
<parameter> Id = "0" Inline = "0" Name = "u2pwm/u2pwm/BT_system/VPS_Speed_Gain1/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "1" Inline = "0" Name = "u2pwm/u2pwm/BT_system/VPS_Speed_Gain2/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "2" Inline = "0" Name = "u2pwm/u2pwm/BT_system/If Action Subsystem2/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "3" Inline = "0" Name = "u2pwm/u2pwm/BT_system/If Action Subsystem1/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "4" Inline = "0" Name = "u2pwm/u2pwm/BT_system/If Action Subsystem/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "5" Inline = "0" Name = "u2pwm/u2pwm/VPS_Speed_Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "6" Inline = "0" Name = "u2pwm/u2pwm/VPS_Speed_Gain2/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "7" Inline = "0" Name = "u2pwm/u2pwm/VPS_Power_Offset/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "8" Inline = "0" Name = "u2pwm/Switch_subsystem/Memory/X0" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "9" Inline = "0" Name = "u2pwm/STOP/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "10" Inline = "0" Name = "u2pwm/STOP/Constant1/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "11" Inline = "0" Name = "u2pwm/STOP/Constant2/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "12" Inline = "0" Name = "u2pwm/STOP/Constant3/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "13" Inline = "0" Name = "u2pwm/STOP/Constant4/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "14" Inline = "0" Name = "u2pwm/STOP/Constant5/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "15" Inline = "0" Name = "u2pwm/STOP/Constant6/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "16" Inline = "0" Name = "u2pwm/emulate mechanical and electrical system/Integrator6/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "17" Inline = "0" Name = "u2pwm/emulate mechanical and electrical system/Integrator5/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "18" Inline = "0" Name = "u2pwm/emulate mechanical and electrical system/Integrator4/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "19" Inline = "0" Name = "u2pwm/emulate mechanical and electrical system/Integrator3/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "20" Inline = "0" Name = "u2pwm/emulate mechanical and electrical system/Integrator2/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "21" Inline = "0" Name = "u2pwm/emulate mechanical and electrical system/Integrator1/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "22" Inline = "0" Name = "u2pwm/emulate mechanical and electrical system/Integrator/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "23" Inline = "0" Name = "u2pwm/u2pwm/Saturation8/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "24" Inline = "0" Name = "u2pwm/u2pwm/Saturation8/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "25" Inline = "0" Name = "u2pwm/u2pwm/Saturation9/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "26" Inline = "0" Name = "u2pwm/u2pwm/Saturation9/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "27" Inline = "0" Name = "u2pwm/u2pwm/BT_system/Integrator/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "28" Inline = "0" Name = "u2pwm/u2pwm/BT_system/Switch/Threshold" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "29" Inline = "0" Name = "u2pwm/u2pwm/Saturation10/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "30" Inline = "0" Name = "u2pwm/u2pwm/Saturation10/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "31" Inline = "0" Name = "u2pwm/u2pwm/Gain5/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "32" Inline = "0" Name = "u2pwm/u2pwm/Saturation1/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "33" Inline = "0" Name = "u2pwm/u2pwm/Saturation1/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "34" Inline = "0" Name = "u2pwm/u2pwm/Gain3/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "35" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table3/Table" Width = "25" DataType = "real_T" </parameter>
<parameter> Id = "36" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table3/BreakpointsForDimension1" Width = "5" DataType = "real_T" </parameter>
<parameter> Id = "37" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table3/BreakpointsForDimension2" Width = "5" DataType = "real_T" </parameter>
<parameter> Id = "38" Inline = "0" Name = "u2pwm/u2pwm/Gain2/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "39" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table2/Table" Width = "25" DataType = "real_T" </parameter>
<parameter> Id = "40" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table2/BreakpointsForDimension1" Width = "5" DataType = "real_T" </parameter>
<parameter> Id = "41" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table2/BreakpointsForDimension2" Width = "5" DataType = "real_T" </parameter>
<parameter> Id = "42" Inline = "0" Name = "u2pwm/u2pwm/Saturation11/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "43" Inline = "0" Name = "u2pwm/u2pwm/Saturation11/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "44" Inline = "0" Name = "u2pwm/u2pwm/Gain4/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "45" Inline = "0" Name = "u2pwm/u2pwm/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "46" Inline = "0" Name = "u2pwm/u2pwm/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "47" Inline = "0" Name = "u2pwm/u2pwm/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "48" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table/Table" Width = "25" DataType = "real_T" </parameter>
<parameter> Id = "49" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table/BreakpointsForDimension1" Width = "5" DataType = "real_T" </parameter>
<parameter> Id = "50" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table/BreakpointsForDimension2" Width = "5" DataType = "real_T" </parameter>
<parameter> Id = "51" Inline = "0" Name = "u2pwm/u2pwm/Gain1/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "52" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table1/Table" Width = "25" DataType = "real_T" </parameter>
<parameter> Id = "53" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table1/BreakpointsForDimension1" Width = "5" DataType = "real_T" </parameter>
<parameter> Id = "54" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table1/BreakpointsForDimension2" Width = "5" DataType = "real_T" </parameter>
<parameter> Id = "55" Inline = "0" Name = "u2pwm/u2pwm/Saturation7/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "56" Inline = "0" Name = "u2pwm/u2pwm/Saturation7/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "57" Inline = "0" Name = "u2pwm/u2pwm/BT_system/Gain1/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "58" Inline = "0" Name = "u2pwm/u2pwm/BT_system/Gain6/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "59" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table3/maxIndex" Width = "2" DataType = "uint32_T" </parameter>
<parameter> Id = "60" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table2/maxIndex" Width = "2" DataType = "uint32_T" </parameter>
<parameter> Id = "61" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table/maxIndex" Width = "2" DataType = "uint32_T" </parameter>
<parameter> Id = "62" Inline = "0" Name = "u2pwm/u2pwm/2-D Lookup Table1/maxIndex" Width = "2" DataType = "uint32_T" </parameter>
</parameterlist>
