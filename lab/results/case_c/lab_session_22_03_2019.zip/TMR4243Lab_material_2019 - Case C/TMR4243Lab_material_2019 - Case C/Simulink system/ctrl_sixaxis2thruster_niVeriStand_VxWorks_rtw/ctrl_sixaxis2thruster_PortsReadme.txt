<portlist>
<inport> Id = "1"  Name = "PosXLeft" Width = "1" DataType = "real_T" </inport>
<inport> Id = "2"  Name = "PosYLeft" Width = "1" DataType = "real_T" </inport>
<inport> Id = "3"  Name = "PosYRight" Width = "1" DataType = "real_T" </inport>
<inport> Id = "4"  Name = "PosXRight" Width = "1" DataType = "real_T" </inport>
<inport> Id = "5"  Name = "Start" Width = "1" DataType = "real_T" </inport>
<inport> Id = "6"  Name = "ArrowUp" Width = "1" DataType = "real_T" </inport>
<inport> Id = "7"  Name = "L2_continuous" Width = "1" DataType = "real_T" </inport>
<inport> Id = "8"  Name = "R2_continuous" Width = "1" DataType = "real_T" </inport>
<inport> Id = "9"  Name = "ArrowDown" Width = "1" DataType = "real_T" </inport>
<outport> Id = "1"  Name = "u_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "2"  Name = "alpha_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "3"  Name = "alpha_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "4"  Name = "u_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "5"  Name = "u_BT" Width = "1" DataType = "real_T" </outport>
<outport> Id = "6"  Name = "omega_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "7"  Name = "omega_VSP2" Width = "1" DataType = "real_T" </outport>
</portlist>
