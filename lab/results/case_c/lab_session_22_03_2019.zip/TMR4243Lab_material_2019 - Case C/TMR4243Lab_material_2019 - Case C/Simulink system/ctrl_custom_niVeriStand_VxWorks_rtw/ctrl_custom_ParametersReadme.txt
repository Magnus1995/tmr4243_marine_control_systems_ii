<parameterlist>
<parameter> Id = "0" Inline = "0" Name = "ctrl_custom/simpleConversion1/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "1" Inline = "0" Name = "ctrl_custom/simpleConversion1/Gain2/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "2" Inline = "0" Name = "ctrl_custom/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "3" Inline = "0" Name = "ctrl_custom/Gain1/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "4" Inline = "0" Name = "ctrl_custom/simpleConversion1/Gain1/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "5" Inline = "0" Name = "ctrl_custom/Control law/Gain/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "6" Inline = "0" Name = "ctrl_custom/Control law/Gain1/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "7" Inline = "0" Name = "ctrl_custom/Subsystem/Memory1/X0" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "8" Inline = "0" Name = "ctrl_custom/Subsystem/Memory/X0" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "9" Inline = "0" Name = "ctrl_custom/Control law/Memory/X0" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "10" Inline = "0" Name = "ctrl_custom/Control law/Memory1/X0" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "11" Inline = "0" Name = "ctrl_custom/Observer/Integrator/InitialCondition" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "12" Inline = "0" Name = "ctrl_custom/Observer/Integrator1/InitialCondition" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "13" Inline = "0" Name = "ctrl_custom/Control law/Integrator1/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "14" Inline = "0" Name = "ctrl_custom/Control law/Memory3/X0" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "15" Inline = "0" Name = "ctrl_custom/Control law/Memory2/X0" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "16" Inline = "0" Name = "ctrl_custom/u1/Saturation2/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "17" Inline = "0" Name = "ctrl_custom/u1/Saturation2/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "18" Inline = "0" Name = "ctrl_custom/u1/Saturation11/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "19" Inline = "0" Name = "ctrl_custom/u1/Saturation11/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "20" Inline = "0" Name = "ctrl_custom/u1/Saturation1/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "21" Inline = "0" Name = "ctrl_custom/u1/Saturation1/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "22" Inline = "0" Name = "ctrl_custom/Turn rate1/Value" Width = "2" DataType = "real_T" </parameter>
<parameter> Id = "23" Inline = "0" Name = "ctrl_custom/Observer/Integrator2/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "24" Inline = "0" Name = "ctrl_custom/Memory1/X0" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "25" Inline = "0" Name = "ctrl_custom/Memory2/X0" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "26" Inline = "0" Name = "ctrl_custom/Memory3/X0" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "27" Inline = "0" Name = "ctrl_custom/Observer/Band-Limited White Noise/White Noise/Mean" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "28" Inline = "0" Name = "ctrl_custom/Observer/Band-Limited White Noise/White Noise/StdDev" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "29" Inline = "0" Name = "ctrl_custom/Observer/Band-Limited White Noise/White Noise/Seed" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "30" Inline = "0" Name = "ctrl_custom/Observer/Band-Limited White Noise/Output/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "31" Inline = "0" Name = "ctrl_custom/Observer/L5/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "32" Inline = "0" Name = "ctrl_custom/Observer/L4/Gain" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "33" Inline = "0" Name = "ctrl_custom/Switch1/Threshold" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "34" Inline = "0" Name = "ctrl_custom/Observer/D/Value" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "35" Inline = "0" Name = "ctrl_custom/Observer/M/Value" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "36" Inline = "0" Name = "ctrl_custom/Observer/L1/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "37" Inline = "0" Name = "ctrl_custom/Observer/L2/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "38" Inline = "0" Name = "ctrl_custom/Observer/L3/Gain" Width = "9" DataType = "real_T" </parameter>
</parameterlist>
