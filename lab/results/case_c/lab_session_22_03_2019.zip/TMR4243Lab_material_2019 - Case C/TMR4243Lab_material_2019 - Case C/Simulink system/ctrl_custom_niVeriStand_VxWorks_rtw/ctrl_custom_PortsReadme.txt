<portlist>
<inport> Id = "1"  Name = "NIVeriStand In2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "2"  Name = "posXRight" Width = "1" DataType = "real_T" </inport>
<inport> Id = "3"  Name = "R2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "4"  Name = "L2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "5"  Name = "posYLeft" Width = "1" DataType = "real_T" </inport>
<inport> Id = "6"  Name = "Control law/control switch" Width = "1" DataType = "real_T" </inport>
<inport> Id = "7"  Name = "Control law/Kp " Width = "1" DataType = "real_T" </inport>
<inport> Id = "8"  Name = "Control law/Kd" Width = "1" DataType = "real_T" </inport>
<inport> Id = "9"  Name = "Pose/x_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "10"  Name = "Pose/y_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "11"  Name = "Pose/psi_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "12"  Name = "Observer/Noise gain" Width = "1" DataType = "real_T" </inport>
<inport> Id = "13"  Name = "Observer/Observer gain L1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "14"  Name = "Observer/Observer gain L3" Width = "1" DataType = "real_T" </inport>
<inport> Id = "15"  Name = "Observer/Observer gain L2" Width = "1" DataType = "real_T" </inport>
<outport> Id = "1"  Name = "Control law/pd" Width = "3" DataType = "real_T" </outport>
<outport> Id = "2"  Name = "Control law/eta_0_out" Width = "3" DataType = "real_T" </outport>
<outport> Id = "3"  Name = "Control law/s_out" Width = "1" DataType = "real_T" </outport>
<outport> Id = "4"  Name = "Control law/j_control " Width = "1" DataType = "real_T" </outport>
<outport> Id = "5"  Name = "tau_sat" Width = "3" DataType = "real_T" </outport>
<outport> Id = "6"  Name = "eta_hat" Width = "3" DataType = "real_T" </outport>
<outport> Id = "7"  Name = "nu_hat" Width = "3" DataType = "real_T" </outport>
<outport> Id = "8"  Name = "b_hat" Width = "3" DataType = "real_T" </outport>
<outport> Id = "9"  Name = "tau_cmd" Width = "3" DataType = "real_T" </outport>
<outport> Id = "10"  Name = "eta_measured" Width = "3" DataType = "real_T" </outport>
<outport> Id = "11"  Name = "u/alpha_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "12"  Name = "u/omega_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "13"  Name = "u/omega_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "14"  Name = "u/alpha_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "15"  Name = "u/u_BT" Width = "1" DataType = "real_T" </outport>
<outport> Id = "16"  Name = "u/u_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "17"  Name = "u/u_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "18"  Name = "Observer/Eta_bar" Width = "3" DataType = "real_T" </outport>
<outport> Id = "19"  Name = "Subsystem/j_measurement " Width = "1" DataType = "real_T" </outport>
</portlist>
