<signallist>
<signal> Id = "0" Name = "ctrl_custom/posYLeft" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "1" Name = "ctrl_custom/posXLeft" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "2" Name = "ctrl_custom/Selector" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "3" Name = "ctrl_custom/posXRight" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "4" Name = "ctrl_custom/R2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "5" Name = "ctrl_custom/L2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "6" Name = "ctrl_custom/Observer2/Integrator/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "7" Name = "ctrl_custom/Observer2/Integrator/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "8" Name = "ctrl_custom/Observer2/Integrator/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "9" Name = "ctrl_custom/Observer2/Integrator1/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "10" Name = "ctrl_custom/Observer2/Integrator1/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "11" Name = "ctrl_custom/Observer2/Integrator1/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "12" Name = "ctrl_custom/Observer2/Integrator2/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "13" Name = "ctrl_custom/Observer2/Integrator2/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "14" Name = "ctrl_custom/Observer2/Integrator2/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "15" Name = "ctrl_custom/simpleConversion/Gain" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "16" Name = "ctrl_custom/simpleConversion/Gain1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "17" Name = "ctrl_custom/simpleConversion1/Gain" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "18" Name = "ctrl_custom/simpleConversion1/Gain2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "19" Name = "ctrl_custom/simpleConversion1/Gain1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "20" Name = "ctrl_custom/Pose/x_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "21" Name = "ctrl_custom/Pose/y_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "22" Name = "ctrl_custom/Pose/psi_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "23" Name = "ctrl_custom/Memory" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "24" Name = "ctrl_custom/Memory1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "25" Name = "ctrl_custom/Switch/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "26" Name = "ctrl_custom/Switch/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "27" Name = "ctrl_custom/Switch/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "28" Name = "ctrl_custom/Switch/(1, 4)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "29" Name = "ctrl_custom/Switch/(1, 5)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "30" Name = "ctrl_custom/Switch/(1, 6)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "31" Name = "ctrl_custom/Switch/(1, 7)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "32" Name = "ctrl_custom/u1/Saturation2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "33" Name = "ctrl_custom/u1/Saturation11" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "34" Name = "ctrl_custom/u1/Saturation1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "35" Name = "ctrl_custom/Observer2/Noise gain" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "36" Name = "ctrl_custom/Observer2/L4/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "37" Name = "ctrl_custom/Observer2/L4/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "38" Name = "ctrl_custom/Observer2/L4/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "39" Name = "ctrl_custom/Observer2/Sum/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "40" Name = "ctrl_custom/Observer2/Sum/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "41" Name = "ctrl_custom/Observer2/Sum/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "42" Name = "ctrl_custom/Observer2/Observer gain L1//L2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "43" Name = "ctrl_custom/Observer2/Observer gain L3" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "44" Name = "ctrl_custom/Observer2/Product/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "45" Name = "ctrl_custom/Observer2/Product/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "46" Name = "ctrl_custom/Observer2/Product/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "47" Name = "ctrl_custom/Observer2/Product7/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "48" Name = "ctrl_custom/Observer2/Product7/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "49" Name = "ctrl_custom/Observer2/Product7/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "50" Name = "ctrl_custom/Observer2/Sum2/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "51" Name = "ctrl_custom/Observer2/Sum2/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "52" Name = "ctrl_custom/Observer2/Sum2/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "53" Name = "ctrl_custom/IMU/Acc_z" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "54" Name = "ctrl_custom/IMU/Acc_x" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "55" Name = "ctrl_custom/IMU/Acc_y" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "56" Name = "ctrl_custom/IMU/Gyro_x" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "57" Name = "ctrl_custom/IMU/Gyro_y" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "58" Name = "ctrl_custom/IMU/Gyro_z" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "59" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "60" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(2, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "61" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(3, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "62" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "63" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(2, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "64" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(3, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "65" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "66" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(2, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "67" Name = "ctrl_custom/Polar coordinate thrust allocation/BK inverse" SignalName = "(3, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "68" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "69" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(2, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "70" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(3, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "71" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "72" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(2, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "73" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(3, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "74" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "75" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(2, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "76" Name = "ctrl_custom/Observer2/Inverse" SignalName = "(3, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "77" Name = "ctrl_custom/MATLAB Function1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "78" Name = "ctrl_custom/MATLAB Function1" SignalName = "" PortNum = "1" Width = "1" DataType = "real_T" </signal>
<signal> Id = "79" Name = "ctrl_custom/MATLAB Function" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "80" Name = "ctrl_custom/MATLAB Function" SignalName = "" PortNum = "1" Width = "1" DataType = "real_T" </signal>
</signallist>
