% Thruster parameters
l_x_bt = 0.3875;
l_x_vsp1 = -0.4574;
l_y_vsp1 = -0.055;
l_x_vsp2 = -0.4574;
l_y_vsp2 = 0.055;

% Thruster max forces and gains
F_max_bt = 2.629;
F_max_vsp1 = 1.03;
F_max_vsp2 = 1.03;
K = diag([F_max_bt, F_max_vsp1, F_max_vsp2]);

% Test parameters
tau_cmd = [0, 2, 0]';
alphas = [0, 0]';
omegas = [0, 0]';

% Thruster configuration matrix calculation
a_vsp1 = alphas(1);
a_vsp2 = alphas(2);

B = [
        0   cos(a_vsp1)     cos(a_vsp2);
        1   sin(a_vsp1)     sin(a_vsp2);
        l_x_bt  -l_y_vsp1*cos(a_vsp1)+l_x_vsp1*sin(a_vsp1) -l_y_vsp2*cos(a_vsp2)+l_x_vsp2*sin(a_vsp2);
    ];

BK = B*K;
BK_inv = inv(B*K);

u = BK_inv*tau_cmd;

% Pseudo-inverse method
B_pseudo = [
        1           0           1           0           0;
        0           1           0           1           1;
        -l_y_vsp1   l_x_vsp1    -l_y_vsp2   l_x_vsp2    l_x_bt;
    ];

B_inv_pseudo = pinv(B_pseudo);
f_pseudo = B_inv_pseudo*tau_cmd;

% Calculate angles
a_vsp1_pseudo = atan2(f_pseudo(2),f_pseudo(1));
a_vsp2_pseudo = atan2(f_pseudo(4),f_pseudo(3));
alphas_pseudo = [a_vsp1_pseudo, a_vsp2_pseudo]';

% Calculate u's
u_bt = f_pseudo(5)/K(1,1);
u_vsp1 = sqrt(f_pseudo(1)^2 + f_pseudo(2)^2)/K(2,2);
u_vsp2 = sqrt(f_pseudo(3)^2 + f_pseudo(4)^2)/K(3,3);

u_pseudo = [u_bt, u_vsp1, u_vsp2]';