<signallist>
<signal> Id = "0" Name = "ctrl_custom/SIXAIS_INN" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "1" Name = "ctrl_custom/Pose/x_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "2" Name = "ctrl_custom/Pose/y_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "3" Name = "ctrl_custom/Pose/psi_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "4" Name = "ctrl_custom/IMU/Acc_z" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "5" Name = "ctrl_custom/IMU/Acc_x" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "6" Name = "ctrl_custom/IMU/Acc_y" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "7" Name = "ctrl_custom/IMU/Gyro_x" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "8" Name = "ctrl_custom/IMU/Gyro_y" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "9" Name = "ctrl_custom/IMU/Gyro_z" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
</signallist>
