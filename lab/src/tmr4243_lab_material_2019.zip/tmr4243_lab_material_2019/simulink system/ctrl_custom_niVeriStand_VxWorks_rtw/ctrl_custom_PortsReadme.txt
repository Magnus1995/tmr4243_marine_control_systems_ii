<portlist>
<inport> Id = "1"  Name = "SIXAIS_INN" Width = "1" DataType = "real_T" </inport>
<inport> Id = "2"  Name = "Pose/x_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "3"  Name = "Pose/y_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "4"  Name = "Pose/psi_m" Width = "1" DataType = "real_T" </inport>
<inport> Id = "5"  Name = "IMU/Acc_z" Width = "1" DataType = "real_T" </inport>
<inport> Id = "6"  Name = "IMU/Acc_x" Width = "1" DataType = "real_T" </inport>
<inport> Id = "7"  Name = "IMU/Acc_y" Width = "1" DataType = "real_T" </inport>
<inport> Id = "8"  Name = "IMU/Gyro_x" Width = "1" DataType = "real_T" </inport>
<inport> Id = "9"  Name = "IMU/Gyro_y" Width = "1" DataType = "real_T" </inport>
<inport> Id = "10"  Name = "IMU/Gyro_z" Width = "1" DataType = "real_T" </inport>
<outport> Id = "1"  Name = "SIXAIS_OUT" Width = "1" DataType = "real_T" </outport>
<outport> Id = "2"  Name = "QTM_SCOPEX" Width = "1" DataType = "real_T" </outport>
<outport> Id = "3"  Name = "QTM_SCOPEY" Width = "1" DataType = "real_T" </outport>
<outport> Id = "4"  Name = "QTM_SCOPEPSI" Width = "1" DataType = "real_T" </outport>
<outport> Id = "5"  Name = "IMU/IMU_SCOPEZ" Width = "1" DataType = "real_T" </outport>
<outport> Id = "6"  Name = "u/alpha_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "7"  Name = "u/omega_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "8"  Name = "u/omega_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "9"  Name = "u/alpha_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "10"  Name = "u/u_BT" Width = "1" DataType = "real_T" </outport>
<outport> Id = "11"  Name = "u/u_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "12"  Name = "u/u_VSP2" Width = "1" DataType = "real_T" </outport>
</portlist>
