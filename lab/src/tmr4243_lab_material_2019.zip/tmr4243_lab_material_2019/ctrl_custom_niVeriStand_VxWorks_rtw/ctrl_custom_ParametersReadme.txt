<parameterlist>
<parameter> Id = "0" Inline = "0" Name = "ctrl_custom/OBserver/Dead Reckoning ON//OFF  /Dead Reckoning/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "1" Inline = "0" Name = "ctrl_custom/OBserver/Dead Reckoning ON//OFF  /DR on/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "2" Inline = "0" Name = "ctrl_custom/OBserver/SimpleObserver/Integrator/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "3" Inline = "0" Name = "ctrl_custom/OBserver/Switch/Threshold" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "4" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/Integrator/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "5" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator2/InitialCondition" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "6" Inline = "0" Name = "ctrl_custom/Find tau_body/Switch/Threshold" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "7" Inline = "0" Name = "ctrl_custom/Thrust Allocation/Switch1/Threshold" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "8" Inline = "0" Name = "ctrl_custom/Thrust Allocation/Switch/Threshold" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "9" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/IC/Value" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "10" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator/InitialCondition" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "11" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator1/InitialCondition" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "12" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Saturation4/UpperLimit" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "13" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Saturation4/LowerLimit" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "14" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/w_n2/Gain" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "15" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/w_n1/Gain" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "16" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/ciwni/Gain" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "17" Inline = "0" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/w_n/Gain" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "18" Inline = "0" Name = "ctrl_custom/OBserver/Dead Reckoning ON//OFF  /Dummy/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "19" Inline = "0" Name = "ctrl_custom/OBserver/SimpleObserver/L1/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "20" Inline = "0" Name = "ctrl_custom/OBserver/SimpleObserver/Integrator1/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "21" Inline = "0" Name = "ctrl_custom/OBserver/SimpleObserver/L2/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "22" Inline = "0" Name = "ctrl_custom/OBserver/SimpleObserver/D (somewhat weird with 7.25)/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "23" Inline = "0" Name = "ctrl_custom/OBserver/SimpleObserver/B/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "24" Inline = "0" Name = "ctrl_custom/OBserver/SimpleObserver/L3/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "25" Inline = "0" Name = "ctrl_custom/OBserver/SimpleObserver/invM/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "26" Inline = "0" Name = "ctrl_custom/OBserver/Dead Reckoning ON//OFF  /Manual Switch/CurrentSetting" Width = "1" DataType = "uint8_T" </parameter>
</parameterlist>
